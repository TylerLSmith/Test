import base64
import io

import pandas as pd
from dash import ALL, Input, Output, State, dash_table, html
from dash.exceptions import PreventUpdate

from components import data_source_table, generate_report_page
from utils import *


def register_callbacks(app):
    # Upload data to the store
    @app.callback(
        Output("data-store", "data"),
        Input("upload-data", "contents"),
        State("upload-data", "filename"),
    )
    def upload_data(contents, file_name):
        if contents is None:
            # return pd.read_excel("Automated_Presentation_2024Feb26.xlsx").to_dict("records")
            raise PreventUpdate

        # Decode the file and store it in state
        content_type, content_string = contents.split(",")
        decoded = base64.b64decode(content_string)

        try:
            if "csv" in file_name:
                data = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
            elif "xls" in file_name:
                data = pd.read_excel(io.BytesIO(decoded))

            return data.to_dict("records")
        except Exception as e:
            print(e)
            return html.Div(["There was an error processing this file."])

    # Generate the data source table from stored data
    @app.callback(
        [
            Output("data-source-table", "children"),
            Output("select-all", "style"),
        ],
        Input("data-store", "data"),
    )
    def update_datatable(data):
        # If data is uploaded, display checkbox table, the report section, the export button, and the select all checkbox
        if data is None:
            raise PreventUpdate
        display = {"display": "block"}
        return data_source_table(data), display

    # Generate the report section based on the selected unit on the data source table
    @app.callback(
        Output("report-output", "children"),
        Output("report-section", "style"),
        # Output("report-output2", "children"),  # going to be deleted
        Input({"type": "datatable-checkbox", "index": ALL}, "checked"),
        State({"type": "datatable-checkbox", "index": ALL}, "value"),
        State("data-store", "data"),
        prevent_initial_call=True,
    )
    def update_report(checks, values, data):
        display = {"display": "block"}
        # Filter out the checked values for the reports
        sellected = [value for checked, value in zip(checks, values) if checked]
        df = pd.DataFrame(data)

        name = 0
        if not sellected:
            # return generate_report_page(df, name), display, dash_table.DataTable(data=df.to_dict("records"))
            return None, {"display": "none"}  # , None

        # Generate a cumulative report for all selected units
        cumulative_df = df.copy()
        cumulative_df = cumulative_df[cumulative_df["Region"].isin([s.split("|")[0] for s in sellected])]
        cumulative_df = cumulative_df[cumulative_df["Industry"].isin([s.split("|")[1] for s in sellected])]
        cumulative_df = cumulative_df[cumulative_df["Market Cap"].isin([s.split("|")[2] for s in sellected])]

        # List of reports starting with the cumulative report
        content_to_print = [generate_report_page(cumulative_df, name)]

        # If only one unit is selected, return the report for that unit
        if len(sellected) == 1:
            return content_to_print, display  # , dash_table.DataTable(data=cumulative_df.to_dict("records"))

        # Generate report for each selected unit and add it to the list
        for unit in sellected:
            filtered_df = df.copy()
            filtered_df = filtered_df[filtered_df["Region"] == unit.split("|")[0]]
            filtered_df = filtered_df[filtered_df["Industry"] == unit.split("|")[1]]
            filtered_df = filtered_df[filtered_df["Market Cap"] == unit.split("|")[2]]
            name += 1
            content_to_print.append(generate_report_page(filtered_df, name))

        return content_to_print, display  # , dash_table.DataTable(data=filtered_df.to_dict("records"))

    # Select or deselect all checkboxes
    @app.callback(
        Output({"type": "datatable-checkbox", "index": ALL}, "checked"),
        Input("select-all", "checked"),
        State({"type": "datatable-checkbox", "index": ALL}, "disabled"),
        prevent_initial_call=True,
    )
    def check_all_checkbox(checked, disabled):
        # Filter out the disabled checkboxes
        check = [not x for x in disabled]
        if checked:
            return check
        return [False] * len(disabled)

    # Print individual report
    app.clientside_callback(
        """
        function () {

            let export_buttons = document.querySelectorAll('[id^="export-report-number"]')

            for (let i = 0; i < export_buttons.length; i++) {
                let report_id = export_buttons[i].id.split('export-')[1]

                export_buttons[i].addEventListener('click', function() {
                    let printContents = document.getElementById(report_id).innerHTML;
                    let originalContents = document.body.innerHTML;

                    document.body.innerHTML = printContents;
                    window.print();

                    document.body.innerHTML = originalContents;
                    location.reload()
                });

            };

            return window.dash_clientside.no_update
        }
        """,
        Output("report-output", "children", allow_duplicate=True),
        Input("report-output", "children"),
        prevent_initial_call=True,
    )

    # Print all reports
    app.clientside_callback(
        """
        function () { 
            let printContents = document.getElementById('report-output').innerHTML;
            let originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
            location.reload()

            return window.dash_clientside.no_update
        }
        """,
        Output("report-output", "children", allow_duplicate=True),
        Input("export-data", "n_clicks"),
        prevent_initial_call=True,
    )
