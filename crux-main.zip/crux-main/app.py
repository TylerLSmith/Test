from dash import Dash

from callbacks import register_callbacks
from layout import layout

app = Dash(__name__)

server = app.server

app.layout = layout
app.title = "Investment Portfolio Dashboard"
app._favicon = "logo.svg"

with server.app_context():
    register_callbacks(app)

if __name__ == "__main__":
    app.run(debug=True)
