import dash_mantine_components as dmc
from dash import dcc, html

from components import report_section, select_all, upload_input

layout = dmc.MantineProvider(
    theme={
        "breakpoints": {
            "xs": 300,
            "sm": 430,
            "md": 921,
            "lg": 1440,
            "xl": 1920,
        }
    },
    children=dmc.NotificationsProvider(
        [
            html.Main(
                children=[
                    upload_input,
                    select_all,
                    html.Div(id="data-source-table"),
                    report_section,
                    html.Div(id="report-output2"),
                ]
            ),
            dcc.Store(id="data-store"),
        ],
    ),
)
