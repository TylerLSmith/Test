from datetime import datetime

import dash_mantine_components as dmc
import pandas as pd
import plotly.graph_objects as go
from dash import dcc, html
from dash_iconify import DashIconify
from plotly.subplots import make_subplots

from utils import (
    DISTRIBUTION_COLORS,
    LAYOUT,
    datatable_content_colors,
    generate_icon,
    get_initials,
    get_shortname,
    market_cap_colors,
)

#### Data Source Table ####

upload_input = html.Div(
    children=[
        html.H2("Investment Portfolio Dashboard"),
        html.P(
            "This dashboard will help you analyze the current state of your investment portfolio. Please upload your data to get started. Then, select the unit you want to include in the report.",
            className="body-text1 text-center",
        ),
        html.Div(
            children=[
                html.P("Click ", className="body-text2"),
                html.P("Export Reports", className="body-text2 bold"),
                html.P(" button to download all reports!", className="body-text2"),
            ],
            className="text-center export-instructions",
        ),
        html.P(
            "Click download icon to download individual report. The icon will appear when you hover top right corner of the each report",
            className="text-center export-instructions body-text2",
        ),
        dcc.Upload(
            id="upload-data",
            children=html.Div(
                ["Drag and Drop or ", html.A("Select Files")],
                className="bold",
            ),
        ),
    ],
    className="basic-card info-card",
)

select_all = dmc.Switch(
    id="select-all",
    offLabel="Select All",
    onLabel="Clear All",
    size="xl",
    style={"display": "none"},
    className="select-all-switch",
)


def data_source_table(data):
    df = pd.DataFrame(data)

    # Get unique values to create the table cells
    regions = sorted(df["Region"].unique())
    industries = sorted(df["Industry"].unique())
    market_cap = sorted(df["Market Cap"].unique())

    # Reorder market_cap
    market_cap = [cap for cap in ["Large", "Medium", "Small", "Micro"] if cap in market_cap]

    # Create the sidebar with the industries
    sidebar = html.Div(
        [
            html.P(
                [
                    DashIconify(icon=generate_icon(industry), width=20),
                    industry,
                ],
                className="body-text1",
            )
            for industry in industries
        ],
        className="data-source-table-sidebar",
    )

    # Create the content of the table
    content = [
        html.Div(
            [
                html.H3(region, className=f"region-title {'left' if regions.index(region) % 2 == 0 else 'right'}"),
                html.Div(
                    [
                        html.Div(
                            html.P(cap, className="subtitle"),
                            className="table-cell",
                            # Set the class name to the left or right side of the table for styling
                            style={"backgroundColor": market_cap_colors["left" if regions.index(region) % 2 == 0 else "right"][market_cap.index(cap)]},
                        )
                        for cap in market_cap
                    ],
                    className="market-cap-title",
                ),
                *[
                    html.Div(
                        [
                            html.Div(
                                dmc.Checkbox(
                                    label=f"{get_initials(region)}-{get_initials(ind)}-{get_initials(cap)}",
                                    value=f"{region}|{ind}|{cap}",
                                    # Set the class name to the left or right side of the table for styling
                                    className=f"body-text2 bold checkbox-{'left' if regions.index(region) % 2 == 0 else 'right'}",
                                    id={"type": "datatable-checkbox", "index": f"{region}-{ind}-{cap}"},
                                    checked=False,
                                    # Disable the checkbox if there is no data for that unit
                                    disabled=len(df[(df["Region"] == region) & (df["Industry"] == ind) & (df["Market Cap"] == cap)]) == 0,
                                ),
                                className="table-cell",
                                style={"backgroundColor": datatable_content_colors[market_cap.index(cap) % len(datatable_content_colors)]},
                            )
                            for cap in market_cap
                        ],
                    )
                    for ind in industries
                ],
            ],
            className="data-source-table-region",
        )
        for region in regions
    ]

    return html.Div(
        className="data-source-table",
        children=[
            sidebar,
            html.Div(content, className="data-source-table-content"),
        ],
    )


export_input = html.Button(
    "Export Reports",
    id="export-data",
    className="subtitle",
)


#### Reports ####

skeleton = html.Div("There is no data related to this metric.", className="subtitle basic-card text-center")
space = html.Div(className="dont-print")

report_title = html.Div(
    children=[
        html.H2("Reports Based on Selected Units"),
        export_input,
    ],
    className="report-title",
)


report_section = html.Div(
    children=[
        report_title,
        html.Div(id="report-output"),
    ],
    className="report-section",
    id="report-section",
    style={"display": "none"},
)


def generate_area_chart(df, metric, colorscale=None):

    metric_df = df[df["Metric"].str.contains(metric)]
    metric_df = metric_df.groupby("Date").sum().reset_index().sort_values("Date")

    current_year = metric_df["Value"].iloc[-1]
    last_year = metric_df["Value"].iloc[-2]
    percentaje_change = 100 * (current_year - last_year) / last_year

    line_chart = go.Figure()

    line_chart.add_trace(
        go.Scatter(
            x=metric_df["Date"],
            y=metric_df["Value"],
            fill="tozeroy",
            mode="lines",
            line={"width": 0, "shape": "spline"},
            fillgradient={
                "type": "vertical",
                "colorscale": [(0.0, colorscale[0]), (0.75, colorscale[1]), (1.0, colorscale[2])] if colorscale else None,
            },
            hoverinfo="y+x",
        )
    )

    line_chart.add_annotation(
        x=0,
        y=1,
        xanchor="left",
        yanchor="bottom",
        text=metric,
        font={"size": 16},
    )

    line_chart.add_annotation(
        x=1,
        y=1,
        xanchor="right",
        yanchor="bottom",
        text=f"${current_year:,.0f}",
        font={"size": 16, "color": "#2e6aa3"},
    )

    line_chart.add_annotation(
        x=0,
        y=-0.05,
        xanchor="left",
        yanchor="top",
        text="Previous Year",
        font={"size": 8, "color": "#2e6aa3"},
    )

    line_chart.add_annotation(
        x=0,
        y=-0.2,
        xanchor="left",
        yanchor="top",
        text=f"${last_year:,.0f}",
        font={"size": 10},
    )

    line_chart.add_annotation(
        x=1,
        y=-0.05,
        xanchor="right",
        yanchor="top",
        text="+/- Change",
        font={"size": 8, "color": "#2e6aa3"},
    )

    line_chart.add_annotation(
        x=1,
        y=-0.2,
        xanchor="right",
        yanchor="top",
        text=f"{percentaje_change:,.2f}%",
        font={
            "size": 10,
            "color": "red" if percentaje_change < 0 else "green",
        },
    )

    line_chart.update_layout(LAYOUT)
    line_chart.update_layout(
        height=100,
        hoverlabel={"bgcolor": "#3c84c8"},
    )

    line_chart.update_annotations(
        {
            "xref": "paper",
            "yref": "paper",
            "showarrow": False,
        }
    )

    return dcc.Graph(
        figure=line_chart,
        className="basic-card",
        config={"displayModeBar": False},
    )


def generate_portfolio_growth_chart(df, metric):

    metric_df = df[df["Metric"].str.contains(metric)]
    metric_df = metric_df.groupby("Date").sum().reset_index().sort_values("Date")

    actual_growth = metric_df[metric_df["Metric"].str.contains("actual")]
    planned_growth = metric_df[metric_df["Metric"].str.contains("plan")]

    maximum = max(actual_growth["Value"].max(), planned_growth["Value"].max())

    growth_chart = go.Figure(
        data=[
            go.Bar(
                name="Actual Growth",
                x=actual_growth["Date"],
                y=actual_growth["Value"],
                marker={"color": "#4C7E80"},
                text=actual_growth["Value"],
            ),
            go.Bar(
                name="Planned Growth",
                x=planned_growth["Date"],
                y=planned_growth["Value"],
                marker={"color": "#8CB6DE"},
                text=planned_growth["Value"],
            ),
        ]
    )

    growth_chart.update_traces(
        texttemplate="$%{text:.2s}",
        textposition="inside",
        insidetextanchor="start",
        hoverinfo="y+x",
    )

    growth_chart.update_layout(LAYOUT)
    growth_chart.update_layout(
        barmode="group",
        height=200,
        bargroupgap=0.1,
        xaxis={"showticklabels": True, "automargin": True},
        yaxis={"range": [-(maximum * 0.1), maximum * 1.1]},
        legend={
            "orientation": "h",
            "xref": "container",
            "yref": "container",
            "x": 0.5,
            "xanchor": "center",
        },
    )

    growth_chart.add_annotation(
        x=0,
        y=1,
        xanchor="left",
        yanchor="bottom",
        xref="paper",
        yref="paper",
        text="Portfolio Growth",
        showarrow=False,
        font={"size": 16},
    )

    return dcc.Graph(
        figure=growth_chart,
        className="basic-card",
        config={"displayModeBar": False},
    )


def generate_industry_distribution(df, metric):

    metric_df = df[df["Metric"].str.contains(metric)]

    labels = [x.split("(")[1].split(")")[0] for x in metric_df["Metric"].unique()]
    values = [metric_df[metric_df["Metric"].str.contains(x)]["Value"].sum() for x in labels]

    distribution_chart = go.Figure(
        data=[
            go.Pie(
                labels=[label if len(label) < 13 else get_shortname(label) for label in labels],
                values=values,
                textinfo="percent",
                textposition="inside",
                marker={"colors": DISTRIBUTION_COLORS},
            )
        ],
    )

    distribution_chart.update_layout(LAYOUT)
    distribution_chart.update_layout(
        height=200,
        margin={"t": 20, "b": 0, "l": 0, "r": 0},
        legend={"y": 0.5, "yanchor": "middle"},
    )

    distribution_chart.add_annotation(
        x=0,
        y=1,
        xanchor="left",
        yanchor="bottom",
        xref="paper",
        yref="paper",
        text="Top Industries",
        showarrow=False,
        font={"size": 16},
    )

    return dcc.Graph(
        figure=distribution_chart,
        className="basic-card",
        config={"displayModeBar": False},
    )


def generate_utilization_chart(df, metric):

    metric_df1 = df[df["Metric"].str.contains(metric + ".1")]
    metric_df2 = df[df["Metric"].str.contains(metric + ".2")]

    labels = ["TVaR Utilized", "CY Remainder"]
    values1 = [metric_df1[metric_df1["Metric"].str.contains(x.split()[1])]["Value"].sum() for x in labels]
    values2 = [metric_df2[metric_df2["Metric"].str.contains(x.split()[1])]["Value"].sum() for x in labels]

    utilization_chart = make_subplots(
        rows=1,
        cols=2,
        specs=[[{"type": "domain"}, {"type": "domain"}]],
    )

    utilization_chart.add_trace(go.Pie(labels=labels, values=values1), 1, 1)
    utilization_chart.add_trace(go.Pie(labels=labels, values=values2), 1, 2)

    utilization_chart.update_traces(
        hole=0.3,
        hoverinfo="label+percent+value",
        marker={"colors": ["#3C84C8", "#8CB6DE"]},
        textinfo="value",
        textposition="inside",
        texttemplate="$%{value:.2s}",
    )

    utilization_chart.update_layout(LAYOUT)
    utilization_chart.update_layout(
        height=180,
        margin={"t": 20, "b": 0, "l": 0, "r": 0},
        legend={"y": 0.5, "yanchor": "middle"},
        annotations=[
            {
                "text": "HU",
                "x": 0.18,
                "y": 0.5,
                "font_size": 12,
                "showarrow": False,
            },
            {
                "text": "EQ",
                "x": 0.82,
                "y": 0.5,
                "font_size": 12,
                "showarrow": False,
            },
        ],
    )

    utilization_chart.add_annotation(
        x=0,
        y=1,
        xanchor="left",
        yanchor="bottom",
        xref="paper",
        yref="paper",
        text="YTD Utilization",
        showarrow=False,
        font={"size": 16},
    )

    return dcc.Graph(
        figure=utilization_chart,
        className="basic-card",
        config={"displayModeBar": False},
    )


def generate_trend_chart(df, metric):

    metric_df1 = df[df["Metric"].str.contains(metric + ".1")]
    metric_df1 = metric_df1.groupby("Date").sum().reset_index().sort_values("Date")

    metric_df2 = df[df["Metric"].str.contains(metric + ".2")]
    metric_df2 = metric_df2.groupby("Date").sum().reset_index().sort_values("Date")

    maximum = max(metric_df1["Value"].max(), metric_df2["Value"].max())

    trend_chart = go.Figure()

    trend_chart.add_trace(
        go.Bar(
            name="Rate",
            x=metric_df1["Date"],
            y=metric_df1["Value"],
            marker={"color": "#8cb6de"},
            text=metric_df1["Value"],
            textposition="auto",
            insidetextanchor="start",
        ),
    )

    trend_chart.add_trace(
        go.Scatter(
            name="Capital",
            x=metric_df2["Date"],
            y=metric_df2["Value"],
            text=metric_df2["Value"],
            marker={"color": "#4C7E80", "size": 10},
            mode="lines+markers+text",
            textposition="top center",
            line={"width": 1},
        )
    )

    trend_chart.update_traces(texttemplate="$%{text:.2s}", hoverinfo="y+x")

    trend_chart.update_layout(LAYOUT)
    trend_chart.update_layout(
        height=180,
        xaxis={"showticklabels": True, "automargin": True},
        yaxis={"range": [-(maximum * 0.1), maximum * 1.5]},
        legend={
            "orientation": "h",
            "xref": "container",
            "yref": "container",
            "x": 0.5,
            "xanchor": "center",
        },
    )

    trend_chart.add_annotation(
        x=0,
        y=1,
        xanchor="left",
        yanchor="bottom",
        xref="paper",
        yref="paper",
        text="Rate & Capital Trends",
        showarrow=False,
        font={"size": 16},
    )

    return dcc.Graph(
        figure=trend_chart,
        className="basic-card",
        config={"displayModeBar": False},
    )


def generate_report_page(df, name):

    regions = sorted(df["Region"].unique())
    industries = sorted(df["Industry"].unique())
    market_cap = sorted(df["Market Cap"].unique())

    # Sidebar
    sidebar_content = []

    for i, group in enumerate([regions, market_cap, industries]):
        icon = [
            "carbon:location",
            "ant-design:bar-chart-outlined",
            "la:industry",
        ][i]
        sidebar_content.append(
            html.Div(
                [
                    html.P(
                        [
                            DashIconify(icon=icon, width=20),
                            text,
                        ],
                        className="body-text1",
                    )
                    for text in group
                ]
            )
        )

    sidebar_content.append(
        html.P(
            f'Data as of {datetime.now().strftime("%m.%d.%Y")}',
            className="footnote-font",
        )
    )

    sidebar = html.Div(
        sidebar_content,
        className="report-sidebar",
    )

    # Charts
    metric1 = "Metric 1"
    metric2 = "Metric 2"
    metric3 = "Metric 3"
    metric4 = "Metric 4"
    metric5 = "Metric 5"
    metric6 = "Metric 6"
    metric7 = "Metric 7"
    metric8 = "Metric 8"

    metric_1_chart = generate_area_chart(df, metric1, colorscale=["#2E6AA3", "#5F9EA0", "#5F9EA0"]) if df["Metric"].str.contains(metric1).any() else skeleton
    metric_2_chart = generate_area_chart(df, metric2, colorscale=["#5F9EA0", "#2E6AA3", "#2E6AA3"]) if df["Metric"].str.contains(metric2).any() else skeleton
    metric_3_chart = generate_area_chart(df, metric3, colorscale=["#5F9EA0", "#183653", "#183653"]) if df["Metric"].str.contains(metric3).any() else skeleton
    metric_4_chart = generate_area_chart(df, metric4, colorscale=["#183653", "#9FC5C6", "#9FC5C6"]) if df["Metric"].str.contains(metric4).any() else skeleton

    metric_5_chart = generate_portfolio_growth_chart(df, metric5) if df["Metric"].str.contains(metric5).any() else skeleton
    metric_6_chart = generate_industry_distribution(df, metric6) if df["Metric"].str.contains(metric6).any() else skeleton
    metric_7_chart = generate_utilization_chart(df, metric7) if df["Metric"].str.contains(metric7).any() else skeleton
    metric_8_chart = generate_trend_chart(df, metric8) if df["Metric"].str.contains(metric8).any() else skeleton

    content = dmc.Grid(
        [
            dmc.Col(metric_1_chart, span=3),
            dmc.Col(metric_2_chart, span=3),
            dmc.Col(metric_3_chart, span=3),
            dmc.Col(metric_4_chart, span=3),
            dmc.Col(metric_5_chart, span=8),
            dmc.Col(metric_6_chart, span=4),
            dmc.Col(metric_7_chart, span=6),
            dmc.Col(metric_8_chart, span=6),
        ],
        align="stretch",
    )

    note = html.P("Tyler Smith Portfolio", className="footnote-font bold footnote")

    export_button = html.Button(
        # "Export Reports",
        DashIconify(icon="material-symbols:download", width=24),
        id=f"export-report-number-{name}",
        className="subtitle single-report-export-buttons",
    )

    return html.Div(
        children=[
            html.Div(
                children=[
                    html.Div(
                        className="single-report-container",
                        children=[
                            sidebar,
                            content,
                            export_button,
                        ],
                    ),
                    note,
                ]
            ),
            space,
        ],
        id=f"report-number-{name}",
    )

    # return html.Div(
    #     children=[
    #         html.Div(
    #             className="single-report-container",
    #             children=[
    #                 sidebar,
    #                 content,
    #             ],
    #         ),
    #         note,
    #     ],
    # )
