def get_initials(text):
    return "".join(word[0].upper() for word in text.split() if word.isalpha())


def get_shortname(text):
    if len(text.split()) > 1:
        return "".join(word[0].upper() for word in text.split() if word.isalpha())
    else:
        return text[:3].title()


datatable_content_colors = [
    "#c4cdd5",
    "#dfe3e8",
    "#f4f6f8",
    "#f9fafb",
]

market_cap_colors = {
    "left": [
        "#183653",
        "#2e6aa3",
        "#3c84c8",
        "#8cb6de",
    ],
    "right": [
        "#395f60",
        "#4c7e80",
        "#5f9ea0",
        "#9fc5c6",
    ],
}

# Iconset for industries
ICON_DICT = {
    "Automotive": "clarity:auto-line",
    "Banking": "mdi-bank",
    "Chemicals": "mdi-flask",
    "Construction": "mdi-hammer",
    "Consumer Goods": "mdi-shopping",
    "Energy": "mdi-oil",
    "Financial Services": "mdi-cash",
    "Healthcare": "mdi-hospital",
    "Hospitality": "mdi-hotel",
    "Insurance": "mdi-shield",
    "Manufacturing": "mdi-factory",
    "Media": "mdi-television",
    "Mining": "mdi-axe",
    "Pharmaceuticals": "mdi-pill",
    "Real Estate": "material-symbols-light:real-estate-agent-outline",
    "Retail": "mdi-store",
    "Technology": "mdi-laptop",
    "Telecommunications": "mdi-phone",
    "Transportation": "mdi-train",
    "Utilities": "mdi-flash",
}


def generate_icon(industy):

    try:
        return ICON_DICT[industy]
    except:
        return "la:industry"


# Define default the layout for charts
LAYOUT = {
    "margin": {
        "l": 0,
        "r": 0,
        "t": 20,
        "b": 25,
    },
    "xaxis": {
        "showgrid": False,
        "showticklabels": False,
        "tickformat": "%b %Y",
    },
    "yaxis": {
        "showgrid": False,
        "showticklabels": False,
    },
    "plot_bgcolor": "#f0f8ff",
    "paper_bgcolor": "#f0f8ff",
    "legend": {
        "font": {
            "size": 10,
        },
    },
    "font": {
        "family": "Sans-Serif",
        "color": "#183653",
    },
}


DISTRIBUTION_COLORS = [
    "#183653",
    "#5f9ea0",
    "#8cb6de",
    "#dbe8f5",
    "#3c84c8",
    "#395f60",
    "#dceef8",
    "#13415c",
    "#a7db9e",
    "#2e6aa3",
    "#295921",
    "#e6e88d",
    "#8b8c1d",
    "#f9e1e1",
    "#ffa48d",
    "#d63838",
    "#611414",
    "#af8cf1",
    "#300e70",
    "#915eeb",
    "#c0f8e7",
    "#36e9b3",
    "#12a77a",
]
